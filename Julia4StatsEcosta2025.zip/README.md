# Julia for Statistics - a tutorial

This repo contains material for a tutorial on Julia for statistics. 
See the webpage: [Julia for Statistics](https://mattiasvillani.com/Julia4Stats)